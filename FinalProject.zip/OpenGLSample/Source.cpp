﻿// Matthew Rix
// Module 7 Final | CS-330 | SNHU
// 8/11/2022

/* Controls:
 *   W:              Forward
  *  A:              Backward
   * S:              Left
    D:              Right
    Q:              Down
    E:              Up
    P:			    Hold for orthographic viewing, default is perspective
    [:              Texture Scaling -
    ]:              Texture Scaling +
    Scroll Wheel:	Zooms the camera in and out (changes FOV)
*/

#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h" // Image loading Utility functions

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "GLFW/camera.h" // Camera class


using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Final Project 7-1"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        // Handle for the vertex array object
        GLuint cylinderVao;
        GLuint planeVao;
        GLuint circleVao;
        GLuint cubeVao;
        GLuint sphereVao;
        GLuint pyramidVao;
        // Handle for the vertex buffer object
        GLuint cylinderVbo;
        GLuint planeVbo;
        GLuint circleVbo;
        GLuint cubeVbo;
        GLuint sphereVbo;
        GLuint pyramidVbo;
        // Number of indices of the mesh
        GLuint nCylinderVertices;
        GLuint nPlaneVertices;
        GLuint nCircleVertices;
        GLuint nCubeVertices;
        GLuint nSphereVertices;
        GLuint nPyramidVertices;
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    GLMesh gMesh;
    // Texture
    GLuint gTextureFloor;
    GLuint gTextureCoilTop;
    GLuint gTextureCoilShaft;
    GLuint gTextureCoilBase;
    GLuint gTextureCircle;
    GLuint gTextureTorchTop;
    GLuint gTextureTorchBase;
    GLuint gTextureSpinnerPlane;
    GLuint gTextureSpinnerBase;
    GLuint gTextureSphere;
    GLuint gTexturePyramid;


    glm::vec2 gUVScale(1.0f, 1.0f);
    GLint gTexWrapMode = GL_REPEAT;

    // Shader programs
    GLuint programId;
    //Coil
    GLuint gCoilShaftProgramId;
    GLuint gCoilTopProgramId;
    GLuint gCoilBaseProgramId;
    //Light
    GLuint gLightProgramId;
    //Floor
    GLuint gFloorProgramId;
    //Circle
    GLuint gCircleProgramId;
    //Sphere
    GLuint gSphereProgramId;
    //Torch
    GLuint gTorchTopProgramId;
    GLuint gTorchBaseProgramId;
    //Pyramid
    GLuint gPyramidProgramId;
    //Spinner
    GLuint gSpinnerBaseProgramId;
    GLuint gSpinnerPlaneProgramId;


    // camera
    Camera gCamera(glm::vec3(5.5f, 10.0f, 8.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    // globals
    bool keys[1024];
    bool ortho = false;			// Sets orthographic projection

    // Coil Shaft position and scale
    glm::vec3 gCoilTopPosition(5.0f, 2.5f, 0.0f);
    glm::vec3 gCoilTopScale(2.0f, 0.25f, 2.0f);
    // Coil Top position and scale
    glm::vec3 gCoilShaftPosition(5.0f, 0.5f, 0.0f);
    glm::vec3 gCoilShaftScale(0.5f, 2.0f, 0.5);
    // Coil Base position and scale
    glm::vec3 gCoilBasePosition(5.0f, 0.0f, 0.0f);
    glm::vec3 gCoilBaseScale(1.0f, 0.5f, 1.0f);
    // Lamp Light position and scale
    glm::vec3 gLampLightPosition(3.55f, 8.4f, -4.35f);
    glm::vec3 gLampLightScale(0.3f);
    glm::vec3 gLampLightColor(1.0f, 1.0f, 1.0f);
    glm::vec3 gLampLightObjectColor(1.0f, 1.0f, 1.0f);

    // Floor position and scale
    glm::vec3 gFloorPosition(-5.0f, 0.0f, 5.0f);
    glm::vec3 gFloorScale(30.0f, 0.0f, 30.0f);
    // Floor Light position and scale
    glm::vec3 gFloorLightPosition(3.55f, 4.4f, 4.35f);
    glm::vec3 gFloorLightScale(0.3f);
    glm::vec3 gFloorLightColor(1.0f, 1.0f, 1.0f);
    glm::vec3 gFloorLightObjectColor(1.0f, 1.0f, 1.0f);

    // Circle position and scale
    glm::vec3 gCirclePosition(5.0f, 2.8f, 0.0f);
    glm::vec3 gCircleScale(1.5f, 1.5f, 1.5f);

    // Torch Top position and scale
    glm::vec3 gTorchTopPosition(-2.0f, 8.0f, 4.5f);
    glm::vec3 gTorchTopScale(2.0f, 2.0f, 2.0f);

    // Torch Base position and scale
    glm::vec3 gTorchBasePosition(-2.0f, 0.0f, 4.5f);
    glm::vec3 gTorchBaseScale(2.0f, 8.0f, 2.0f);

    // Pyramid position and scale
    glm::vec3 gPyramidPosition(-1.0f, 0.0f, -1.0f);
    glm::vec3 gPyramidScale(1.0f, 1.0f, 1.0f);

    // Sphere position and scale
    glm::vec3 gSpherePosition(0.0f, 0.0f, -5.0f);
    glm::vec3 gSphereScale(1.5f, 1.5f, 1.5f);

    // Spinner Plane position and scale
    glm::vec3 gSpinnerPlanePosition(1.85f, 2.51f, -2.85f);
    glm::vec3 gSpinnerPlaneScale(4.5f, 0.1f, 0.5f);

    // Spinner Base position and scale
    glm::vec3 gSpinnerBasePosition(3.0f, 0.0f, -3.0f);
    glm::vec3 gSpinnerBaseScale(0.05f, 2.5f, 0.05f);

}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMeshPlane(GLMesh& mesh);
void UCreateMeshCircle(GLMesh& mesh);
void UCreateMeshCylinder(GLMesh& mesh);
void UCreateMeshPyramid(GLMesh& mesh);
void UCreateMeshCube(GLMesh& mesh);
void UCreateMeshSphere(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


//Coil Shaft Vertex Shader Source Code============================================================================================================
const GLchar* CoilShaftVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


//CoilShaft Fragment Shader Source Code>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
const GLchar* CoilShaftFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.15f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 1.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);



//Floor Vertex Shader Source Code============================================================================================================
const GLchar* floorVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


//Floor Fragment Shader Source Code>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
const GLchar* floorFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing floor color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.5f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 4.0f; // Set specular light strength
    float highlightSize = 8.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

//Coil Top Vertex Shader Source Code============================================================================================================
const GLchar* CoilTopVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


//Coil Top Fragment Shader Source Code>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
const GLchar* CoilTopFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing floor color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = -0.12f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 0.6f; // Set specular light strength
    float highlightSize = 2.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 0.0); // Send lighting results to GPU
}
);


//Coil Base Vertex Shader Source Code============================================================================================================
const GLchar* CoilBaseVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


/* Coil Base Fragment Shader Source Code*/
const GLchar* CoilBaseFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.5f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 8.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

//Circle Vertex Shader Source Code============================================================================================================
const GLchar* CircleVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


/* Circle Fragment Shader Source Code*/
const GLchar* CircleFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 1.8f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 8.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);


//Light Vertex Shader Source Code============================================================================================================
const GLchar* LightVertexShaderSource = GLSL(440,


    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

        //Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);



/* light Fragment Shader Source Code*/
const GLchar* LightFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);

//Torch Top Vertex Shader Source Code============================================================================================================
const GLchar* TorchTopVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


//Torch Top Fragment Shader Source Code>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
const GLchar* TorchTopFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.15f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 1.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);
//Torch Base Vertex Shader Source Code============================================================================================================
const GLchar* TorchBaseVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


//torch Base Fragment Shader Source Code>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
const GLchar* TorchBaseFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.15f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 1.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);
//Spinner Plane Vertex Shader Source Code============================================================================================================
const GLchar* SpinnerPlaneVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


//Spinner Plane Fragment Shader Source Code>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
const GLchar* SpinnerPlaneFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.15f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 1.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

//Spinner Base Vertex Shader Source Code============================================================================================================
const GLchar* SpinnerBaseVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


//Spinner Base Fragment Shader Source Code>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
const GLchar* SpinnerBaseFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.35f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 1.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

//Sphere Vertex Shader Source Code============================================================================================================
const GLchar* SphereVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


//SphereFragment Shader Source Code>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
const GLchar* SphereFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.65f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 1.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

//Pyramid Vertex Shader Source Code============================================================================================================
const GLchar* PyramidVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


//Pyramid Fragment Shader Source Code>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
const GLchar* PyramidFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.65f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 1.5f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);
// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the Cylinder mesh######################################################################################################################################
    UCreateMeshCylinder(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader programs
    if (!UCreateShaderProgram(CoilShaftVertexShaderSource, CoilShaftFragmentShaderSource, gCoilShaftProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(CoilTopVertexShaderSource, CoilTopFragmentShaderSource, gCoilTopProgramId))
        return EXIT_FAILURE;


    if (!UCreateShaderProgram(CoilBaseVertexShaderSource, CoilBaseFragmentShaderSource, gCoilBaseProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(SpinnerBaseVertexShaderSource, SpinnerBaseFragmentShaderSource, gSpinnerBaseProgramId))
        return EXIT_FAILURE;


    if (!UCreateShaderProgram(LightVertexShaderSource, LightFragmentShaderSource, gLightProgramId))
        return EXIT_FAILURE;

    // Create the Plane mesh######################################################################################################################################
    UCreateMeshPlane(gMesh); // Calls the function to create the Vertex Buffer Object

    if (!UCreateShaderProgram(floorVertexShaderSource, floorFragmentShaderSource, gFloorProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(SpinnerPlaneVertexShaderSource, SpinnerPlaneFragmentShaderSource, gSpinnerPlaneProgramId))
        return EXIT_FAILURE;

    // Create the Circle mesh######################################################################################################################################
    UCreateMeshCircle(gMesh); // Calls the function to create the Vertex Buffer Object

    if (!UCreateShaderProgram(CircleVertexShaderSource, CircleFragmentShaderSource, gCircleProgramId))
        return EXIT_FAILURE;
    
    // Create the Cube mesh######################################################################################################################################
    UCreateMeshCube(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader programs
    if (!UCreateShaderProgram(TorchTopVertexShaderSource, TorchTopFragmentShaderSource, gTorchTopProgramId))
        return EXIT_FAILURE;
    
    if (!UCreateShaderProgram(TorchBaseVertexShaderSource, TorchBaseFragmentShaderSource, gTorchBaseProgramId))
        return EXIT_FAILURE;
    
    // Create the Sphere mesh######################################################################################################################################
    UCreateMeshSphere(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader programs
    if (!UCreateShaderProgram(SphereVertexShaderSource, SphereFragmentShaderSource, gSphereProgramId))
        return EXIT_FAILURE;
    
    // Create the Pyramid mesh######################################################################################################################################
    UCreateMeshPyramid(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader programs
    if (!UCreateShaderProgram(PyramidVertexShaderSource, PyramidFragmentShaderSource, gPyramidProgramId))
        return EXIT_FAILURE;

    // Load textures

    //All textures used under Creative Commons CC0 public domain.

    //Floor texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const char* texFloor = "../resources/textures/carpet.jpg";
    if (!UCreateTexture(texFloor, gTextureFloor))
    {
        cout << "Failed to load texture " << texFloor << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gFloorProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gFloorProgramId, "uTexture"), 0);

    //Coil Top texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const char* texCoilTop = "../resources/textures/CoilTop.jpg";
    if (!UCreateTexture(texCoilTop, gTextureCoilTop))
    {
        cout << "Failed to load texture " << texCoilTop << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gCoilTopProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gCoilTopProgramId, "uTexture"), 0);

    //Coil Shaft texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const char* texCoilShaft = "../resources/textures/greyLego.jpg";
    if (!UCreateTexture(texCoilShaft, gTextureCoilShaft))
    {
        cout << "Failed to load texture " << texCoilShaft << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gCoilShaftProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gCoilShaftProgramId, "uTexture"), 0);

    // Coil Base texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const char* texCoilBase = "../resources/textures/lego.jpg";
    if (!UCreateTexture(texCoilBase, gTextureCoilBase))
    {
        cout << "Failed to load texture " << texCoilBase << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gCoilBaseProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gCoilBaseProgramId, "uTexture"), 0);

    // Circle texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const char* texCircle = "../resources/textures/circle.jpg";
    if (!UCreateTexture(texCircle, gTextureCircle))
    {
        cout << "Failed to load texture " << texCircle << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gCircleProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gCircleProgramId, "uTexture"), 0);

    //Torch top texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const char* texTorchTop = "../resources/textures/TorchTop.jpg";
    if (!UCreateTexture(texTorchTop, gTextureTorchTop))
    {
        cout << "Failed to load texture " << texTorchTop << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gTorchTopProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gTorchTopProgramId, "uTexture"), 0);

    //Torch Bottom texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const char* texTorchBase = "../resources/textures/TorchBase.jpg";
    if (!UCreateTexture(texTorchBase, gTextureTorchBase))
    {
        cout << "Failed to load texture " << texTorchBase << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gTorchBaseProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gTorchBaseProgramId, "uTexture"), 0);

    //Spinner Base texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const char* texSpinnerBase = "../resources/textures/PropBase.jpg";
    if (!UCreateTexture(texSpinnerBase, gTextureSpinnerBase))
    {
        cout << "Failed to load texture " << texSpinnerBase << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gSpinnerBaseProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gSpinnerBaseProgramId, "uTexture"), 0);


    //Spinner Plane texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const char* texSpinnerPlane = "../resources/textures/PropTop.jpg";
    if (!UCreateTexture(texSpinnerPlane, gTextureSpinnerPlane))
    {
        cout << "Failed to load texture " << texSpinnerPlane << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gSpinnerPlaneProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gSpinnerPlaneProgramId, "uTexture"), 0);

    //Sphere texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const char* texSphere = "../resources/textures/sphere.jpg";
    if (!UCreateTexture(texSphere, gTextureSphere))
    {
        cout << "Failed to load texture " << texSphere << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gSphereProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gSphereProgramId, "uTexture"), 0);

    //Pyramid texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const char* texPyramid = "../resources/textures/pyramid.jpg";
    if (!UCreateTexture(texPyramid, gTexturePyramid))
    {
        cout << "Failed to load texture " << texPyramid << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gPyramidProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gPyramidProgramId, "uTexture"), 0);
    // texture ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 1.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMesh);

    // Release texture
    UDestroyTexture(gTextureFloor);
    UDestroyTexture(gTextureCoilTop);
    UDestroyTexture(gTextureCoilShaft);
    UDestroyTexture(gTextureCoilBase);
    UDestroyTexture(gTextureCircle);
    UDestroyTexture(gTextureTorchTop);
    UDestroyTexture(gTextureTorchBase);
    UDestroyTexture(gTextureSpinnerPlane);
    UDestroyTexture(gTextureSpinnerBase);
    UDestroyTexture(gTextureSphere);
    UDestroyTexture(gTexturePyramid);

    // Release shader programs
    UDestroyShaderProgram(gCoilShaftProgramId);
    UDestroyShaderProgram(gCoilBaseProgramId);
    UDestroyShaderProgram(gCoilTopProgramId);
    UDestroyShaderProgram(gFloorProgramId);
    UDestroyShaderProgram(gTorchTopProgramId);
    UDestroyShaderProgram(gTorchBaseProgramId);
    UDestroyShaderProgram(gSpinnerBaseProgramId);
    UDestroyShaderProgram(gSpinnerPlaneProgramId);
    UDestroyShaderProgram(gCircleProgramId);
    UDestroyShaderProgram(gSphereProgramId);
    UDestroyShaderProgram(gPyramidProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully


}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{

    static const float cameraSpeed = 2.0f;

    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
    {
        gCamera.WorldUp = glm::vec3(0.0f, -1.0f, 0.0f);
        ortho = true;
    }
    else
    {
        gCamera.WorldUp = glm::vec3(0.0f, 1.0f, 0.0f);
        ortho = false;
    }

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS && gTexWrapMode != GL_REPEAT)
    {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_REPEAT;

        cout << "Current Texture Wrapping Mode: REPEAT" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS && gTexWrapMode != GL_MIRRORED_REPEAT)
    {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_MIRRORED_REPEAT;

        cout << "Current Texture Wrapping Mode: MIRRORED REPEAT" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS && gTexWrapMode != GL_CLAMP_TO_EDGE)
    {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_CLAMP_TO_EDGE;

        cout << "Current Texture Wrapping Mode: CLAMP TO EDGE" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_4) == GLFW_PRESS && gTexWrapMode != GL_CLAMP_TO_BORDER)
    {
        float color[] = { 1.0f, 0.0f, 1.0f, 1.0f };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_CLAMP_TO_BORDER;

        cout << "Current Texture Wrapping Mode: CLAMP TO BORDER" << endl;
    }

    if (glfwGetKey(window, GLFW_KEY_RIGHT_BRACKET) == GLFW_PRESS)
    {
        gUVScale += 0.05f;
        cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_LEFT_BRACKET) == GLFW_PRESS)
    {
        gUVScale -= 0.05f;
        cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" << endl;
    }
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

// Functioned called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.5f, 0.5f, 0.58f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


    //*****************************************************BEGIN CUBE ACTIVATION**********************************************************************************************************************
    // Activate the cube VAO
    glBindVertexArray(gMesh.cubeVao);

    // TORCH TOP: draw Torch Top
   //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   // Set the shader to be used
    glUseProgram(gTorchTopProgramId);

    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = glm::translate(gTorchTopPosition) * glm::scale(gTorchTopScale);
    glm::mat4 projection;
    glm::mat4 view;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gTorchTopProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gTorchTopProgramId, "view");
    GLint projLoc = glGetUniformLocation(gTorchTopProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the color, light color, light position, and camera position
    GLint windowObjectColorLoc = glGetUniformLocation(gTorchTopProgramId, "objectColor");
    GLint windowLightColorLoc = glGetUniformLocation(gTorchTopProgramId, "lightColor");
    GLint windowLightPositionLoc = glGetUniformLocation(gTorchTopProgramId, "lightPos");
    GLint viewPositionLoc = glGetUniformLocation(gTorchTopProgramId, "viewPosition");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform3f(windowObjectColorLoc, gLampLightColor.r, gLampLightObjectColor.g, gLampLightObjectColor.b);
    glUniform3f(windowLightColorLoc, gLampLightColor.r, gLampLightColor.g, gLampLightColor.b);
    glUniform3f(windowLightPositionLoc, gLampLightPosition.x, gLampLightPosition.y, gLampLightPosition.z);
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    GLint UVScaleLoc = glGetUniformLocation(gTorchTopProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureTorchTop);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nCubeVertices);

    // CUBE: draw Torch Base
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Set the shader to be used
    glUseProgram(gTorchBaseProgramId);

    // Model matrix: transformations are applied right-to-left order
    model = glm::translate(gTorchBasePosition) * glm::scale(gTorchBaseScale);

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gTorchBaseProgramId, "model");
    viewLoc = glGetUniformLocation(gTorchBaseProgramId, "view");
    projLoc = glGetUniformLocation(gTorchBaseProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    windowObjectColorLoc = glGetUniformLocation(gTorchBaseProgramId, "objectColor");
    windowLightColorLoc = glGetUniformLocation(gTorchBaseProgramId, "lightColor");
    windowLightPositionLoc = glGetUniformLocation(gTorchBaseProgramId, "lightPos");
    viewPositionLoc = glGetUniformLocation(gTorchBaseProgramId, "viewPosition");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform3f(windowObjectColorLoc, gLampLightColor.r, gLampLightObjectColor.g, gLampLightObjectColor.b);
    glUniform3f(windowLightColorLoc, gLampLightColor.r, gLampLightColor.g, gLampLightColor.b);
    glUniform3f(windowLightPositionLoc, gLampLightPosition.x, gLampLightPosition.y, gLampLightPosition.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    UVScaleLoc = glGetUniformLocation(gTorchBaseProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureTorchBase);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nCubeVertices);


    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);
    //*****************************************************END CUBE ACTIVATION***************************************************************************************************************************

    //*****************************************************BEGIN CYLINDER ACTIVATION**********************************************************************************************************************
    // Activate the cylinder VAO
    glBindVertexArray(gMesh.cylinderVao);

    // COIL: draw Coil Shaft
       //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
       // Set the shader to be used
    glUseProgram(gCoilShaftProgramId);

    // Model matrix: transformations are applied right-to-left order
    model = glm::translate(gCoilShaftPosition) * glm::scale(gCoilShaftScale);

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gCoilShaftProgramId, "model");
    viewLoc = glGetUniformLocation(gCoilShaftProgramId, "view");
    projLoc = glGetUniformLocation(gCoilShaftProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Stove Shader program for the cub color, light color, light position, and camera position
    windowObjectColorLoc = glGetUniformLocation(gCoilShaftProgramId, "objectColor");
    windowLightColorLoc = glGetUniformLocation(gCoilShaftProgramId, "lightColor");
    windowLightPositionLoc = glGetUniformLocation(gCoilShaftProgramId, "lightPos");
    viewPositionLoc = glGetUniformLocation(gCoilShaftProgramId, "viewPosition");

    // Pass color, light, and camera data to the Stove Shader program's corresponding uniforms
    glUniform3f(windowObjectColorLoc, gLampLightColor.r, gLampLightObjectColor.g, gLampLightObjectColor.b);
    glUniform3f(windowLightColorLoc, gLampLightColor.r, gLampLightColor.g, gLampLightColor.b);
    glUniform3f(windowLightPositionLoc, gLampLightPosition.x, gLampLightPosition.y, gLampLightPosition.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    UVScaleLoc = glGetUniformLocation(gCoilShaftProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureCoilShaft);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nCylinderVertices);

    // COIL: draw Coil Top
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    // Set the shader to be used
    glUseProgram(gCoilTopProgramId);

    // Model matrix: transformations are applied right-to-left order
    model = glm::translate(gCoilTopPosition) * glm::scale(gCoilTopScale);

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gCoilTopProgramId, "model");
    viewLoc = glGetUniformLocation(gCoilTopProgramId, "view");
    projLoc = glGetUniformLocation(gCoilTopProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the cylinder color, light color, light position, and camera position
    windowObjectColorLoc = glGetUniformLocation(gCoilTopProgramId, "objectColor");
    windowLightColorLoc = glGetUniformLocation(gCoilTopProgramId, "lightColor");
    windowLightPositionLoc = glGetUniformLocation(gCoilTopProgramId, "lightPos");
    viewPositionLoc = glGetUniformLocation(gCoilTopProgramId, "viewPosition");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform3f(windowObjectColorLoc, gLampLightColor.r, gLampLightObjectColor.g, gLampLightObjectColor.b);
    glUniform3f(windowLightColorLoc, gLampLightColor.r, gLampLightColor.g, gLampLightColor.b);
    glUniform3f(windowLightPositionLoc, gLampLightPosition.x, gLampLightPosition.y, gLampLightPosition.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    UVScaleLoc = glGetUniformLocation(gCoilTopProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureCoilTop);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nCylinderVertices);

    // COIL: draw Coil Base
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    // Set the shader to be used
    glUseProgram(gCoilBaseProgramId);

    // Model matrix: transformations are applied right-to-left order
    model = glm::translate(gCoilBasePosition) * glm::scale(gCoilBaseScale);

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gCoilBaseProgramId, "model");
    viewLoc = glGetUniformLocation(gCoilBaseProgramId, "view");
    projLoc = glGetUniformLocation(gCoilBaseProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Coil Base Shader program for the cub color, light color, light position, and camera position
    windowObjectColorLoc = glGetUniformLocation(gCoilBaseProgramId, "objectColor");
    windowLightColorLoc = glGetUniformLocation(gCoilBaseProgramId, "lightColor");
    windowLightPositionLoc = glGetUniformLocation(gCoilBaseProgramId, "lightPos");
    viewPositionLoc = glGetUniformLocation(gCoilBaseProgramId, "viewPosition");

    // Pass color, light, and camera data to the Coil Base Shader program's corresponding uniforms
    glUniform3f(windowObjectColorLoc, gLampLightColor.r, gLampLightObjectColor.g, gLampLightObjectColor.b);
    glUniform3f(windowLightColorLoc, gLampLightColor.r, gLampLightColor.g, gLampLightColor.b);
    glUniform3f(windowLightPositionLoc, gLampLightPosition.x, gLampLightPosition.y, gLampLightPosition.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    UVScaleLoc = glGetUniformLocation(gCoilBaseProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureCoilBase);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nCylinderVertices);


// CYLINDER: draw Spinner Base
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Set the shader to be used
    glUseProgram(gSpinnerBaseProgramId);

    // Model matrix: transformations are applied right-to-left order
    model = glm::translate(gSpinnerBasePosition) * glm::scale(gSpinnerBaseScale);

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gSpinnerBaseProgramId, "model");
    viewLoc = glGetUniformLocation(gSpinnerBaseProgramId, "view");
    projLoc = glGetUniformLocation(gSpinnerBaseProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    windowObjectColorLoc = glGetUniformLocation(gSpinnerBaseProgramId, "objectColor");
    windowLightColorLoc = glGetUniformLocation(gSpinnerBaseProgramId, "lightColor");
    windowLightPositionLoc = glGetUniformLocation(gSpinnerBaseProgramId, "lightPos");
    viewPositionLoc = glGetUniformLocation(gSpinnerBaseProgramId, "viewPosition");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform3f(windowObjectColorLoc, gLampLightColor.r, gLampLightObjectColor.g, gLampLightObjectColor.b);
    glUniform3f(windowLightColorLoc, gLampLightColor.r, gLampLightColor.g, gLampLightColor.b);
    glUniform3f(windowLightPositionLoc, gLampLightPosition.x, gLampLightPosition.y, gLampLightPosition.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    UVScaleLoc = glGetUniformLocation(gSpinnerBaseProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureSpinnerBase);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nCylinderVertices);


    //  LIGHT: draw light
   //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    glUseProgram(gLightProgramId);

    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gLampLightPosition) * glm::scale(gLampLightScale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLightProgramId, "model");
    viewLoc = glGetUniformLocation(gLightProgramId, "view");
    projLoc = glGetUniformLocation(gLightProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nCylinderVertices);

    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);
    //*****************************************************END CYLINDER ACTIVATION****************************************************************

    //*****************************************************BEGIN CIRCLE ACTIVATION****************************************************************
    // Activate the circle VAO
    glBindVertexArray(gMesh.circleVao);

    // CIRCLE: draw Circle
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    // Set the shader to be used
    glUseProgram(gCircleProgramId);

    // Model matrix: transformations are applied right-to-left order
    model = glm::translate(gCirclePosition) * glm::scale(gCircleScale);

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gCircleProgramId, "model");
    viewLoc = glGetUniformLocation(gCircleProgramId, "view");
    projLoc = glGetUniformLocation(gCircleProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Circle Shader program for the circle color, light color, light position, and camera position
    windowObjectColorLoc = glGetUniformLocation(gCircleProgramId, "objectColor");
    windowLightColorLoc = glGetUniformLocation(gCircleProgramId, "lightColor");
    windowLightPositionLoc = glGetUniformLocation(gCircleProgramId, "lightPos");
    viewPositionLoc = glGetUniformLocation(gCircleProgramId, "viewPosition");

    // Pass color, light, and camera data to the Circle Shader program's corresponding uniforms
    glUniform3f(windowObjectColorLoc, gLampLightColor.r, gLampLightObjectColor.g, gLampLightObjectColor.b);
    glUniform3f(windowLightColorLoc, gLampLightColor.r, gLampLightColor.g, gLampLightColor.b);
    glUniform3f(windowLightPositionLoc, gLampLightPosition.x, gLampLightPosition.y, gLampLightPosition.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    UVScaleLoc = glGetUniformLocation(gCircleProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureCircle);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nCircleVertices);

    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);

    //*****************************************************END CIRCLE ACTIVATION****************************************************************

    //*****************************************************BEGIN PLANE ACTIVATION****************************************************************
    // Activate the plane VAO
    glBindVertexArray(gMesh.planeVao);

    // Floor: draw floor
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    // Set the shader to be used
    glUseProgram(gFloorProgramId);

    // Model matrix: transformations are applied right-to-left order
    model = glm::translate(gFloorPosition) * glm::scale(gFloorScale);

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gFloorProgramId, "model");
    viewLoc = glGetUniformLocation(gFloorProgramId, "view");
    projLoc = glGetUniformLocation(gFloorProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Floor Shader program for the cub color, light color, light position, and camera position
    windowObjectColorLoc = glGetUniformLocation(gFloorProgramId, "objectColor");
    windowLightColorLoc = glGetUniformLocation(gFloorProgramId, "lightColor");
    windowLightPositionLoc = glGetUniformLocation(gFloorProgramId, "lightPos");
    viewPositionLoc = glGetUniformLocation(gFloorProgramId, "viewPosition");

    // Pass color, light, and camera data to the Floor Shader program's corresponding uniforms
    glUniform3f(windowObjectColorLoc, gFloorLightColor.r, gFloorLightObjectColor.g, gFloorLightObjectColor.b);
    glUniform3f(windowLightColorLoc, gFloorLightColor.r, gFloorLightColor.g, gFloorLightColor.b);
    glUniform3f(windowLightPositionLoc, gFloorPosition.x, gFloorPosition.y, gFloorPosition.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    UVScaleLoc = glGetUniformLocation(gFloorProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureFloor);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nCylinderVertices);

// PLANE: draw Spinner Plane
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Set the shader to be used
    glUseProgram(gSpinnerPlaneProgramId);

    // Model matrix: transformations are applied right-to-left order
    model = glm::translate(gSpinnerPlanePosition) * glm::scale(gSpinnerPlaneScale);

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gSpinnerPlaneProgramId, "model");
    viewLoc = glGetUniformLocation(gSpinnerPlaneProgramId, "view");
    projLoc = glGetUniformLocation(gSpinnerPlaneProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    windowObjectColorLoc = glGetUniformLocation(gSpinnerPlaneProgramId, "objectColor");
    windowLightColorLoc = glGetUniformLocation(gSpinnerPlaneProgramId, "lightColor");
    windowLightPositionLoc = glGetUniformLocation(gSpinnerPlaneProgramId, "lightPos");
    viewPositionLoc = glGetUniformLocation(gSpinnerPlaneProgramId, "viewPosition");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform3f(windowObjectColorLoc, gLampLightColor.r, gLampLightObjectColor.g, gLampLightObjectColor.b);
    glUniform3f(windowLightColorLoc, gLampLightColor.r, gLampLightColor.g, gLampLightColor.b);
    glUniform3f(windowLightPositionLoc, gLampLightPosition.x, gLampLightPosition.y, gLampLightPosition.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    UVScaleLoc = glGetUniformLocation(gSpinnerPlaneProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureSpinnerPlane);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nPlaneVertices);

    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);
    //*****************************************************END PLANE ACTIVATION****************************************************************

    //*****************************************************BEGIN SPHERE ACTIVATION**********************************************************************************************************************
    // Activate the sphere VAO
    glBindVertexArray(gMesh.sphereVao);

    // SPHERE: draw sphere 
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Set the shader to be used
    glUseProgram(gSphereProgramId);

    // Model matrix: transformations are applied right-to-left order
    model = glm::translate(gSpherePosition) * glm::scale(gSphereScale);

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gSphereProgramId, "model");
    viewLoc = glGetUniformLocation(gSphereProgramId, "view");
    projLoc = glGetUniformLocation(gSphereProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    windowObjectColorLoc = glGetUniformLocation(gSphereProgramId, "objectColor");
    windowLightColorLoc = glGetUniformLocation(gSphereProgramId, "lightColor");
    windowLightPositionLoc = glGetUniformLocation(gSphereProgramId, "lightPos");
    viewPositionLoc = glGetUniformLocation(gSphereProgramId, "viewPosition");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform3f(windowObjectColorLoc, gLampLightColor.r, gLampLightObjectColor.g, gLampLightObjectColor.b);
    glUniform3f(windowLightColorLoc, gLampLightColor.r, gLampLightColor.g, gLampLightColor.b);
    glUniform3f(windowLightPositionLoc, gLampLightPosition.x, gLampLightPosition.y, gLampLightPosition.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    UVScaleLoc = glGetUniformLocation(gSphereProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureSphere);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nSphereVertices);

    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);
    //*****************************************************END SPHERE ACTIVATION***************************************************************************************************************************

    //*****************************************************BEGIN PYRAMID ACTIVATION**********************************************************************************************************************
    // Activate the pyramid VAO
    glBindVertexArray(gMesh.pyramidVao);

    // PYRAMID: draw pyramid
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    // Set the shader to be used
    glUseProgram(gPyramidProgramId);

    // Model matrix: transformations are applied right-to-left order
    model = glm::translate(gPyramidPosition) * glm::scale(gPyramidScale);

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gPyramidProgramId, "model");
    viewLoc = glGetUniformLocation(gPyramidProgramId, "view");
    projLoc = glGetUniformLocation(gPyramidProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    windowObjectColorLoc = glGetUniformLocation(gPyramidProgramId, "objectColor");
    windowLightColorLoc = glGetUniformLocation(gPyramidProgramId, "lightColor");
    windowLightPositionLoc = glGetUniformLocation(gPyramidProgramId, "lightPos");
    viewPositionLoc = glGetUniformLocation(gPyramidProgramId, "viewPosition");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform3f(windowObjectColorLoc, gLampLightColor.r, gLampLightObjectColor.g, gLampLightObjectColor.b);
    glUniform3f(windowLightColorLoc, gLampLightColor.r, gLampLightColor.g, gLampLightColor.b);
    glUniform3f(windowLightPositionLoc, gLampLightPosition.x, gLampLightPosition.y, gLampLightPosition.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    UVScaleLoc = glGetUniformLocation(gPyramidProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTexturePyramid);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nPyramidVertices);

    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);
    //*****************************************************END PYRAMID ACTIVATION***************************************************************************************************************************

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}

void UCreateMeshCylinder(GLMesh& mesh)

{
    // Cylinder Position and Color data
    GLfloat cylinder[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Bottom Face========================================================================================================
        //T1                  //Negative Z Normal  Texture Coords.
       -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V1
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V0
        0.5f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V2
        //T2
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.5f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V2
        0.8f,  0.0f, -0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V3
        //T3
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.8f,  0.0f, -0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V3
        1.0f,  0.0f, -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V4
        //T4
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        1.0f,  0.0f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V4
        1.0f,  0.0f,  0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V5
        //T4
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        1.0f,  0.0f,  0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V5
        0.8f,  0.0f,  0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V6
        //T6
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.8f,  0.0f,  0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V6
        0.5f,  0.0f,  1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V7
        //T7
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.5f,  0.0f,  1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V7
       -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V8
        //T8
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
       -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V8
       -0.8f,  0.0f,  0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V9
        //T9
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
       -0.8f,  0.0f,  0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V9
       -1.0f,  0.0f,  0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V10
        //T10
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
       -1.0f,  0.0f,  0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V10
       -1.0f,  0.0f, -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V11
        //T11
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
       -1.0f,  0.0f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V11
       -0.8f,  0.0f, -0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V12
        //T12
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
       -0.8f,  0.0f, -0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V12
       -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V1

       //TOP FACE========================================================================================================
        //T13                 //Negative Z Normal  Texture Coords.
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
       -0.5f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V14
        0.5f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V15
        //T14
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
        0.5f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V15
        0.8f,  1.0f, -0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V16
        //T15
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
        0.8f,  1.0f, -0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V16
        1.0f,  1.0f, -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V17
        //T16
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
        1.0f,  1.0f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V17
        1.0f,  1.0f,  0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V18
        //T17
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
        1.0f,  1.0f,  0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V18
        0.8f,  1.0f,  0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V19
        //T18
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
        0.8f,  1.0f,  0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V19
        0.5f,  1.0f,  1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V20
        //T19
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
        0.5f,  1.0f,  1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V20
       -0.5f,  1.0f,  1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V21
        //T20
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
       -0.5f,  1.0f,  1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V21
       -0.8f,  1.0f,  0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V22
        //T21
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
       -0.8f,  1.0f,  0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V22
       -1.0f,  1.0f,  0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V23
        //T22
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
       -1.0f,  1.0f,  0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V23
       -1.0f,  1.0f, -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V24
        //T23
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
       -1.0f,  1.0f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V24
       -0.8f,  1.0f, -0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V25
        //T24
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V13
       -0.8f,  1.0f, -0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V25
       -0.5f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V14

       //SIDE FACE========================================================================================================
        //T1                 //Negative Z Normal  Texture Coords.
           -0.5f, 0.0f, -1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V1
           -0.5f, 1.0f, -1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V14
            0.5f, 0.0f, -1.0f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V2
        //T2
           -0.5f, 1.0f, -1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V14
            0.5f, 1.0f, -1.0f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,//V15
            0.5f, 0.0f, -1.0f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V2
        //T3
            0.5f, 0.0f, -1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V2
            0.5f, 1.0f, -1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V15
            0.8f, 0.0f, -0.8f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V3
        //T4
            0.5f, 1.0f, -1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V15
            0.8f, 1.0f, -0.8f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,//V16
            0.8f, 0.0f, -0.8f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V3
        //T4
            0.8f, 0.0f, -0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V3
            0.8f, 1.0f, -0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V16
            1.0f, 0.0f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V4
        //T6
            0.8f, 1.0f, -0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V16
            1.0f, 1.0f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,//V17
            1.0f, 0.0f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V4
        //T7
            1.0f, 0.0f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V4
            1.0f, 1.0f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V17
            1.0f, 0.0f, 0.5f, 0.0f, 0.0f, -1.0f,  1.0f, 0.0f,//V5
        //T8
            1.0f, 1.0f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V17
            1.0f, 1.0f, 0.5f, 0.0f, 0.0f,  -1.0f, 1.0f, 1.0f,//V18
            1.0f, 0.0f, 0.5f, 0.0f, 0.0f,  -1.0f, 1.0f, 0.0f,//V5
        //T9
            1.0f, 0.0f,  0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V5
            1.0f, 1.0f, 0.5f, 0.0f, 0.0f,  -1.0f, 0.0f, 1.0f,//V18
            0.8f, 0.0f, 0.8f, 0.0f, 0.0f,  -1.0f, 1.0f, 0.0f,//V6
        //T10
            1.0f, 1.0f, 0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V18
            0.8f, 1.0f, 0.8f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,//V19
            0.8f, 0.0f, 0.8f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V6
        //T11
            0.8f, 0.0f, 0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V6
            0.8f, 1.0f, 0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V19
            0.5f, 0.0f, 1.0f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V7
        //T12
            0.8f, 1.0f, 0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V19
            0.5f, 1.0f, 1.0f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,//V20
            0.5f, 0.0f, 1.0f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V7
       //T13                 
            0.5f, 0.0f, 1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V7
            0.5f, 1.0f, 1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V20
            -0.5f, 0.0f, 1.0f, 0.0f, 0.0f,-1.0f, 1.0f, 0.0f,//V8
         //T14
            0.5f, 1.0f, 1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V20
            -0.5f, 1.0f, 1.0f, 0.0f, 0.0f,-1.0f, 1.0f, 1.0f,//V21
            -0.5f, 0.0f, 1.0f, 0.0f, 0.0f,-1.0f, 1.0f, 0.0f,//V8
         //T15
            -0.5f, 0.0f, 1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V8
            -0.5f, 1.0f, 1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V21
            -0.8f, 0.0f, 0.8f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V9
         //T16
            -0.5f, 1.0f, 1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V21
            -0.8f, 1.0f, 0.8f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,//V22
            -0.8f, 0.0f, 0.8f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V9
        //T17
           -0.8f, 0.0f,  0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V9
            -0.8f, 1.0f, 0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V22
            -1.0f, 0.0f, 0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V10
         //T18
            -0.8f, 1.0f, 0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V22
            -1.0f, 1.0f, 0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,//V23
            -1.0f, 0.0f, 0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V10
        //T19
           -1.0f, 0.0f,  0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V10
            -1.0f, 1.0f, 0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V23
            -1.0f, 0.0f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V11
         //T20
            -1.0f, 1.0f, 0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V23
            -1.0f, 1.0f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,//V24
            -1.0f, 0.0f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V11
        //T21
           -1.0f, 0.0f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V11
           -1.0f, 1.0f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V24
           -0.8f, 0.0f, -0.8f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V12
        //T22
           -1.0f, 1.0f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V24
           -0.8f, 1.0f, -0.8f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,//V25
           -0.8f, 0.0f, -0.8f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V12
        //T23
           -0.8f, 0.0f, -0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,//V12
           -0.8f, 1.0f, -0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V25
           -0.5f, 0.0f, -1.0f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V1
        //T24
           -0.8f, 1.0f, -0.8f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,//V25
           -0.5f, 1.0f, -1.0f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,//V14
           -0.5f, 0.0f, -1.0f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f //V1


    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nCylinderVertices = sizeof(cylinder) / (sizeof(cylinder[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.cylinderVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.cylinderVao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.cylinderVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.cylinderVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(cylinder), cylinder, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

        // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
};

void UCreateMeshCircle(GLMesh& mesh)

{
    // Circle Position and Color data
    GLfloat circle[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Bottom Face========================================================================================================
        //T1                  //Negative Z Normal  Texture Coords.
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
       -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V1
        0.5f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V2
        //T2
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.5f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V2
        0.8f,  0.0f, -0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V3
        //T3
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.8f,  0.0f, -0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V3
        1.0f,  0.0f, -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V4
        //T4
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        1.0f,  0.0f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V4
        1.0f,  0.0f,  0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V5
        //T4
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        1.0f,  0.0f,  0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V5
        0.8f,  0.0f,  0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V6
        //T6
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.8f,  0.0f,  0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V6
        0.5f,  0.0f,  1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V7
        //T7
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.5f,  0.0f,  1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V7
       -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V8
        //T8
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
       -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V8
       -0.8f,  0.0f,  0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V9
        //T9
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
       -0.8f,  0.0f,  0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V9
       -1.0f,  0.0f,  0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V10
        //T10
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
       -1.0f,  0.0f,  0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V10
       -1.0f,  0.0f, -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V11
        //T11
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
       -1.0f,  0.0f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V11
       -0.8f,  0.0f, -0.8f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V12
        //T12
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
       -0.8f,  0.0f, -0.8f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V12
       -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f //V1

    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nCircleVertices = sizeof(circle) / (sizeof(circle[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.circleVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.circleVao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.circleVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.circleVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(circle), circle, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

        // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
};

void UCreateMeshPlane(GLMesh& mesh)

{
    // Plane Position and Color data
    GLfloat plane[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Bottom Face========================================================================================================
        //T1                  //Negative Z Normal  Texture Coords.
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.5f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V1
        0.5f,  0.0f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V2
        //T2
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.5f,  0.0f, -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V2
        0.0f,  0.0f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f//V3

    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nPlaneVertices = sizeof(plane) / (sizeof(plane[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.planeVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.planeVao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.planeVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.planeVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(plane), plane, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

        // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
};

void UCreateMeshPyramid(GLMesh& mesh)

{
    //  Pyramid Position and Color data
    GLfloat pyramid[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //T1                  //Negative Z Normal  Texture Coords.
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V1
        0.5f,  1.0f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V0
        0.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V2
        //T2
        0.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V2
        0.5f,  1.0f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V0
        1.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V3
        //T1                  
        1.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V3
        0.5f,  1.0f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V0
        1.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V4
        //T2
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,//V1
        1.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V4
        0.5f,  1.0f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        
        //Bottom Face========================================================================================================
        //T1                  
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V1
        0.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V2
        1.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V3
        //T2
        1.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V3
        1.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V4
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f//V1

    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nPyramidVertices = sizeof(pyramid) / (sizeof(pyramid[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.pyramidVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.pyramidVao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.pyramidVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.pyramidVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(pyramid), pyramid, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

        // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}; 

void UCreateMeshCube(GLMesh& mesh)

{
    // Cube Position and Color data
    GLfloat cube[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Bottom Face========================================================================================================
        //T1                  //Negative Z Normal  Texture Coords.
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V1
        1.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V2
        //T2
        1.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V2
        1.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V3
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        //Top Face========================================================================================================
        //T3
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V4
        0.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V5
        1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V6
        //T4
        1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V6
        1.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V7
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,//V4
        //Right Face========================================================================================================
        //T5                  
        1.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V7
        1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V6
        1.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V2
        //T6
        1.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V2
        1.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V3
        1.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V7
        //Left Face========================================================================================================
        //T7
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V4
        0.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V5
        0.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V1
        //T8
        0.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V1
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V0
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V4
        //Front Face========================================================================================================
        //T9                 
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V0
        0.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V4
        1.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V7
        //T10
        1.0f,  1.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V7
        1.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V3
        0.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V0
        //Back Face========================================================================================================
        //T11
        0.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V1
        0.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V5
        1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,//V6
        //T12
        1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V6
        1.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V2
        0.0f,  0.0f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f //V1

    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nCubeVertices = sizeof(cube) / (sizeof(cube[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.cubeVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.cubeVao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.cubeVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.cubeVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(cube), cube, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

        // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
};

void UCreateMeshSphere(GLMesh& mesh)

{
    // Sphere Position and Color data
    GLfloat sphere[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //============================================== TOP ==========================================================
        //T1                  //Negative Z Normal  Texture Coords.
        0.0f,  1.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V1
        0.5f,  1.5f,  -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V0
        1.0f,  1.25f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V2
        //T2
        1.0f,  1.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V2
        0.5f,  1.5f,  -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V0
        1.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V3
        //T3
        1.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V3
        0.5f,  1.5f,  -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V0
        0.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V4
        //T4
        0.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V4
        0.5f,  1.5f,  -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V0
        0.0f,  1.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V1
        //============================================== BOTTOM ==========================================================
        //T1                  //Negative Z Normal  Texture Coords.
        0.0f,  0.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V6
        0.5f,  0.0f,  -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V5
        1.0f,  0.25f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V7
        //T2
        1.0f,  0.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V7
        0.5f,  0.0f,  -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V5
        1.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V8
        //T3
        1.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V8
        0.5f,  0.0f,  -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V5
        0.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V9
        //T4
        0.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V9
        0.5f,  0.0f,  -0.5f,  0.0f,  0.0f, -1.0f,  0.5f, 1.0f,//V5
        0.0f,  0.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V6
        //============================================== RIGHT ==========================================================
        //T1                  //Negative Z Normal  Texture Coords.
        1.0f,  1.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V2
        1.25f,  0.75f,  -0.5f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V10
        1.0f,  0.25f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V7
        //T2
        1.0f,  0.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V7
        1.25f,  0.75f,  -0.5f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V10
        1.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V8
        //T3
        1.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V8
        1.25f,  0.75f,  -0.5f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V10
        1.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V3
        //T4
        1.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V3
        1.25f,  0.75f,  -0.5f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V10
        1.0f,  1.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V2
        //============================================== LEFT ==========================================================
        //T1                  //Negative Z Normal  Texture Coords.
        0.0f,  1.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V1
       -0.25f,  0.75f,  -0.5f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V11
        0.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V4
        //T2
        0.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V4
       -0.25f,  0.75f,  -0.5f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V11
        0.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V9
        //T3
        0.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V9
       -0.25f,  0.75f,  -0.5f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V11
        0.0f,  0.25f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V6
        //T4
        0.0f,  0.25f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V6
       -0.25f,  0.75f,  -0.5f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V11
        0.0f,  1.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V1
        //============================================== FRONT ==========================================================
        //T1                  //Negative Z Normal  Texture Coords.
        0.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V4
        0.5f,  0.75f,   0.25f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V12
        1.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V3
        //T2
        1.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V3
        0.5f,  0.75f,   0.25f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V12
        1.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V8
        //T3
        1.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V8
        0.5f,  0.75f,   0.25f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V12
        0.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V9
        //T4
        0.0f,  0.25f,  0.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V9
        0.5f,  0.75f,   0.25f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V12
        0.0f,  1.25f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V4
        //============================================== BACK ==========================================================
        //T1                  //Negative Z Normal  Texture Coords.
        0.0f,  1.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V1
        0.5f,  0.75f,  -1.25f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V13
        1.0f,  1.25f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V2
        //T2
        1.0f,  1.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V2
        0.5f,  0.75f,  -1.25f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V13
        1.0f,  0.25f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V7
        //T3
        1.0f,  0.25f, -1.0f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,//V7
        0.5f,  0.75f,  -1.25f,  0.0f,  0.0f, -1.0f,0.5f, 1.0f,//V13
        0.0f,  0.25f, -1.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,//V6
        //T4
            0.0f, 0.25f, -1.0f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,//V6
            0.5f, 0.75f, -1.25f, 0.0f, 0.0f, -1.0f,0.5f, 1.0f,//V13
            0.0f, 1.25f, -1.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f //V1

    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nSphereVertices = sizeof(sphere) / (sizeof(sphere[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.sphereVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.sphereVao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.sphereVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.sphereVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(sphere), sphere, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

        // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
};

void UDestroyMesh(GLMesh& mesh)
{

    glDeleteVertexArrays(1, &mesh.cylinderVao);
    glDeleteBuffers(1, &mesh.cylinderVbo);

    glDeleteVertexArrays(1, &mesh.circleVao);
    glDeleteBuffers(1, &mesh.circleVbo);

    glDeleteVertexArrays(1, &mesh.planeVao);
    glDeleteBuffers(1, &mesh.planeVbo);

    glDeleteVertexArrays(1, &mesh.pyramidVao);
    glDeleteBuffers(1, &mesh.pyramidVbo);

    glDeleteVertexArrays(1, &mesh.cubeVao);
    glDeleteBuffers(1, &mesh.cubeVbo);

    glDeleteVertexArrays(1, &mesh.sphereVao);
    glDeleteBuffers(1, &mesh.sphereVbo);
}


/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}